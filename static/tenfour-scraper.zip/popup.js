const btnRun  = document.getElementById('btn-run');
const btnStop = document.getElementById('btn-stop');
const status  = document.getElementById('status');
const logBox  = document.getElementById('log');
const pWrap   = document.getElementById('progress-wrap');
const pBar    = document.getElementById('progress-bar');

let port = null;

function addLog(msg, cls = '') {
  const line = document.createElement('div');
  if (cls) line.className = cls;
  line.textContent = msg;
  logBox.appendChild(line);
  logBox.scrollTop = logBox.scrollHeight;
}

function setProgress(cur, total) {
  const pct = total > 0 ? Math.round((cur / total) * 100) : 0;
  pBar.style.width = pct + '%';
}

btnRun.addEventListener('click', async () => {
  // アクティブタブ確認
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url?.includes('tenfour-poker.com')) {
    status.textContent = '⚠ tenfour-poker.com のタブをアクティブにしてください';
    return;
  }

  // UI切り替え
  btnRun.disabled = true;
  btnStop.style.display = 'block';
  logBox.style.display = 'block';
  pWrap.style.display = 'block';
  logBox.innerHTML = '';
  status.textContent = '初期化中...';
  setProgress(0, 1);

  // content script 注入
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });

  // ポートで通信
  port = chrome.tabs.connect(tab.id, { name: 'scraper' });

  port.onMessage.addListener(msg => {
    switch (msg.type) {
      case 'start':
        status.textContent = `${msg.total}件のハンドを取得します...`;
        setProgress(0, msg.total);
        break;
      case 'progress':
        status.textContent = `取得中... ${msg.current} / ${msg.total}`;
        setProgress(msg.current, msg.total);
        addLog(msg.log, msg.ok ? '' : 'warn');
        break;
      case 'done':
        status.textContent = `✅ 完了！ ${msg.count}件取得 → ${msg.filename}`;
        setProgress(1, 1);
        addLog(`✅ 完了: ${msg.count}件`, '');
        btnRun.disabled = false;
        btnStop.style.display = 'none';
        port = null;
        break;
      case 'error':
        status.textContent = `❌ エラー: ${msg.message}`;
        addLog(`❌ ${msg.message}`, 'error');
        btnRun.disabled = false;
        btnStop.style.display = 'none';
        port = null;
        break;
      case 'log':
        addLog(msg.message, msg.cls || '');
        break;
    }
  });

  port.onDisconnect.addListener(() => {
    if (btnRun.disabled) {
      status.textContent = '⚠ 接続が切れました。再試行してください。';
      btnRun.disabled = false;
      btnStop.style.display = 'none';
    }
    port = null;
  });

  // 開始命令
  port.postMessage({ type: 'start' });
});

btnStop.addEventListener('click', () => {
  if (port) {
    port.postMessage({ type: 'stop' });
    port = null;
  }
  status.textContent = '中止しました';
  btnRun.disabled = false;
  btnStop.style.display = 'none';
  addLog('⏹ 中止', 'warn');
});

// content.js — tenfour-poker.com ハンド履歴スクレイパー
// popup から chrome.tabs.connect で接続して動作する

(function () {
  'use strict';

  // 多重起動防止
  if (window.__tenfourScraperRunning) {
    console.warn('[TF Scraper] すでに実行中');
    return;
  }

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let stopRequested = false;
  let activePort = null;

  // ポート接続待ち受け
  chrome.runtime.onConnect.addListener(port => {
    if (port.name !== 'scraper') return;
    activePort = port;

    port.onMessage.addListener(async msg => {
      if (msg.type === 'start') {
        window.__tenfourScraperRunning = true;
        stopRequested = false;
        await runScraper(port);
        window.__tenfourScraperRunning = false;
      }
      if (msg.type === 'stop') {
        stopRequested = true;
      }
    });

    port.onDisconnect.addListener(() => {
      stopRequested = true;
      window.__tenfourScraperRunning = false;
      activePort = null;
    });
  });

  // ---- メインスクレイプ処理 ----
  async function runScraper(port) {
    const send = (type, payload = {}) => {
      try { port.postMessage({ type, ...payload }); } catch (_) {}
    };

    // ハンドカード行を収集（元スクリプトと同じ条件）
    const cards = [...document.querySelectorAll('*')].filter(e =>
      /2026|2025/.test(e.textContent) &&
      /bb/.test(e.textContent) &&
      e.children.length > 0 &&
      e.children.length < 8 &&
      e.offsetHeight > 30 &&
      e.offsetHeight < 150
    );

    if (cards.length === 0) {
      send('error', { message: 'ハンドが見つかりません。ブックマークタブを開いているか確認してください。' });
      return;
    }

    send('start', { total: cards.length });
    const results = [];

    for (let i = 0; i < cards.length; i++) {
      if (stopRequested) break;

      cards[i].scrollIntoView({ block: 'center' });
      await sleep(200);
      cards[i].click();
      await sleep(700);

      // オーバーレイ検出
      const overlay = [...document.querySelectorAll('*')].find(e =>
        window.getComputedStyle(e).position === 'fixed' &&
        e.innerText?.includes('ハンドヒストリー詳細')
      );

      if (overlay) {
        const text =
          `${'='.repeat(60)}\n` +
          `ハンド ${i + 1} / ${cards.length}\n` +
          `${'='.repeat(60)}\n` +
          overlay.innerText.trim() + '\n';
        results.push(text);

        send('progress', {
          current: i + 1, total: cards.length,
          ok: true,
          log: `✓ ${i + 1}/${cards.length}: 取得成功`
        });

        // ブックマーク解除ボタンがあれば押す（任意）
        // const bookmarkBtn = overlay.querySelector('button[title="ブックマーク解除"]');
        // if (bookmarkBtn) { bookmarkBtn.click(); await sleep(300); }

      } else {
        results.push(`=== ハンド ${i + 1} (取得失敗) ===\n${cards[i].textContent.trim()}\n`);
        send('progress', {
          current: i + 1, total: cards.length,
          ok: false,
          log: `⚠ ${i + 1}/${cards.length}: オーバーレイなし`
        });
      }

      // オーバーレイを閉じる
      document.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'Escape', keyCode: 27, bubbles: true
      }));
      await sleep(400);
    }

    // ---- ダウンロード ----
    const filename = `hand_history_${new Date().toISOString().slice(0, 10)}.txt`;
    const blob = new Blob([results.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement('a'), {
      href: url, download: filename
    });
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);

    send('done', { count: results.length, filename });
  }
})();
